Files included for Phase 2:
- Report.pdf
- properties_location_offender.csv  (sample of the dataset used in our linear regression model)